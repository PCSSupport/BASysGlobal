


update script to create a temp folder to save files while script is running.
# Logging function
function Write-Log {
param(
[string]$Step,
[string]$Status = "SUCCESS",
[string]$Message = ""
)
$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$logEntry = "[$timestamp] $Step : $Status - $Message"
Write-Output $logEntry
$logEntry | Out-File "C:\programdata\desktop-prov.log" -Append -Encoding UTF8
}

$ErrorActionPreference = "Continue"

Write-Log "=== DESKTOP PROVISIONING STARTED ===" "START"

# 1. Wait For Network Connection
Write-Log "1. Network Check" "START"
$ProgressPreference_bk = $ProgressPreference
$ProgressPreference = 'SilentlyContinue'
do {
$ping = Test-NetConnection '8.8.8.8' -InformationLevel Quiet
if (!$ping) {
Write-Host "Waiting For Network Connection..." -NoNewline
Write-Host " " * 20 -NoNewline
Write-Host "`r" -NoNewline
Start-Sleep -Seconds 5
}
} while (!$ping)
$ProgressPreference = $ProgressPreference_bk
Write-Log "1. Network Check" "SUCCESS" "Connected to 8.8.8.8"

# 3. Prompt for Computer Name + Rename (NO REBOOT)
Write-Log "3. Computer Rename" "START"
try {
$ComputerName = Read-Host "Please enter Computer Name"
if ([string]::IsNullOrWhiteSpace($ComputerName)) {
Write-Log "3. Computer Rename" "SKIPPED" "Empty computer name - continuing without rename"
} else {
Rename-Computer -NewName $ComputerName -Force
Write-Log "3. Computer Rename" "SUCCESS" "Renamed to '$ComputerName' (no reboot triggered)"
}
} catch {
Write-Log "3. Computer Rename" "FAILED" $_.Exception.Message
}

# 4. Create Retreading User
Write-Log "4. Retreading User" "START"
try {
$pw = Read-Host "Enter password for Retreading" -AsSecureString
New-LocalUser -Name "Retreading" -Password $pw -PasswordNeverExpires -AccountNeverExpires | Out-Null
if ($?) {
Write-Log "4. Retreading User" "SUCCESS" "User 'Retreading' created and set to password never expire"
} else {
Write-Log "4. Retreading User" "FAILED" "Failed to create user"
}
} catch {
Write-Log "4. Retreading User" "FAILED" $_.Exception.Message
}

# Add the user to the local 'Users' group
Add‑LocalGroupMember -Group "Users" -Member "Retreading"

# 5. Set Passwords Never Expire
Write-Log "5. PasswordNeverExpires" "START"
try {
$users = Get-LocalUser | Where-Object {$_.Enabled -eq $true}
$users | Set-LocalUser -PasswordNeverExpires $true
Write-Log "5. PasswordNeverExpires" "SUCCESS" "$($users.Count) enabled users updated"
} catch {
Write-Log "5. PasswordNeverExpires" "FAILED" $_.Exception.Message
}

# 6. Remove Bloatware
Write-Log "6. Bloatware Removal" "START"
$bloatCount = 0

$bloated = @(
# LinkedIn‑related (exact known names / patterns)
"*LinkedInForWindows*",
"*LinkedIn.com*",

# Xbox / gaming‑related (Xbox app, overlays, etc.)
"*Microsoft.Xbox*",
"*Microsoft.GamingApp*",
"*Microsoft.XboxIdentityProvider*",
"*Microsoft.XboxGamingOverlay*",
"*Microsoft.XboxApp*",
"*Microsoft.XboxGameCallableUI*",

# Your existing others
"*MicrosoftSolitaireCollection*",
"*BingNews*",
"*BingWeather*",
"*People*",
"*GetHelp*",
"*Getstarted*",
"*MicrosoftOfficeHub*",
"*SkypeApp*",
"*WindowsMaps*"
)
try {
foreach ($pattern in $bloated) {

# Remove per‑user packages
$apps = Get-AppxPackage -AllUsers -Name $pattern -ErrorAction SilentlyContinue
if ($apps) {
$apps | Remove-AppxPackage -AllUsers -ErrorAction SilentlyContinue
$bloatCount += $apps.Count
}

# Remove provisioned for new users
$provApps = Get-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue |
Where-Object DisplayName -like $pattern
if ($provApps) {
$provApps | Remove-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue
$bloatCount += $provApps.Count
}

}
} catch
{}


Write-Log "6. Bloatware Removal" "SUCCESS" "$bloatCount bloatware packages removed"

# 7. Create Folders
Write-Log "7. Create Folders" "START"
$folders = @("C:\Temp\Installers","C:\Temp\Installers\Office")
$folderCount = 0
foreach ($folder in $folders) {
if (-not (Test-Path $folder)) {
New-Item -ItemType Directory -Path $folder | Out-Null
$folderCount++
}
}
Write-Log "7. Create Folders" "SUCCESS" "$folderCount new folders created"

# 8. Download Office Deployment Tool
Write-Log "8. Download ODT" "START"
$destination = "C:\Temp\Installers\Office\officedeploymenttool.exe"
try {
Invoke-WebRequest -Uri "https://download.microsoft.com/download/2/7/A/27AF1BE6-DD20-4CB4-B154-EBAB8A7D4A7E/officedeploymenttool_18129-20158.exe" -OutFile $destination -ErrorAction Stop
if (Test-Path $destination) {
$sizeMB = [math]::Round((Get-Item $destination).Length / 1MB, 2)
Write-Log "8. Download ODT" "SUCCESS" "Downloaded: $sizeMB MB"
} else {
Write-Log "8. Download ODT" "FAILED" "File missing after download"
}
} catch {
Write-Log "8. Download ODT" "FAILED" $_.Exception.Message
}

# 9. Extract Office Deployment Tool
if (Test-Path $destination) {
Write-Log "9. Extract ODT" "START"
try {
Start-Process $destination -ArgumentList "/quiet /extract:C:\Temp\Installers\Office" -Wait -NoNewWindow
if (Test-Path "C:\Temp\Installers\Office\setup.exe") {
Write-Log "9. Extract ODT" "SUCCESS" "setup.exe extracted"
Remove-Item $destination -Force | Out-Null
} else {
Write-Log "9. Extract ODT" "FAILED" "setup.exe not found after extraction"
}
} catch {
Write-Log "9. Extract ODT" "FAILED" $_.Exception.Message
}
}

# 10. Create ODT Config
Write-Log "10. ODT Config" "START"
$configFile = "C:\Temp\Installers\Office\configuration-Office365-x64.xml"
try {
$xmlContent = @"
<Configuration>
<Remove All="TRUE" />
<Display Level="None" AcceptEULA="TRUE" />
</Configuration>
"@
$xmlContent | Out-File $configFile -Encoding UTF8 -ErrorAction Stop
Write-Log "10. ODT Config" "SUCCESS" "Config file created: $configFile"
} catch {
Write-Log "10. ODT Config" "FAILED" $_.Exception.Message
}

# 11. Remove Office Bloatware
Write-Log "11. Office Bloatware" "START"
if ((Test-Path "C:\Temp\Installers\Office\setup.exe") -and (Test-Path $configFile)) {
try {
& "C:\Temp\Installers\Office\setup.exe" /configure $configFile
Write-Log "11. Office Bloatware" "SUCCESS" "Office cleanup completed"
} catch {
Write-Log "11. Office Bloatware" "FAILED" $_.Exception.Message
}
} else {
Write-Log "11. Office Bloatware" "SKIPPED" "setup.exe or config missing"
}

# Never sleep
powercfg /change standby-timeout-ac 0
powercfg /change standby-timeout-dc 0

# Never turn off display
powercfg /change monitor-timeout-ac 0
powercfg /change monitor-timeout-dc 0

# Never turn off disk
powercfg /change disk-timeout-ac 0
powercfg /change disk-timeout-dc 0

# Never hibernate
powercfg /change hibernate-timeout-ac 0
powercfg /change hibernate-timeout-dc 0

# 13. Install NetTerm
Write-Log "13. NetTerm Install" "START"
$netTermPath = "C:\Temp"

if (Test-Path $netTermPath) {
try {
# Fix read-only and blocked status
$file = Get-Item -LiteralPath $netTermPath
if ($file.IsReadOnly) {
$file.IsReadOnly = $false
Write-Log "13. NetTerm Install" "INFO" "Cleared read-only on $netTermPath"
}
Unblock-File -LiteralPath $netTermPath -ErrorAction SilentlyContinue

Start-Process $netTermPath -ArgumentList '/s /v"/qn"' -Wait
Write-Log "13. NetTerm Install" "SUCCESS" "NetTerm installed from $netTermPath"
} catch {
Write-Log "13. NetTerm Install" "FAILED" $_.Exception.Message
}
} else {
Write-Log "13. NetTerm Install" "FAILED" "nt325620.exe not found: $netTermPath"
}

# Fix attributes on config files too
$iniPath = "c:\temp\basys_netterm.ini"
$taskPath = "c:\temp\ini.ps1"

# Ensure source files are not blocked/read-only
if (Test-Path $iniPath) {
$file = Get-Item -LiteralPath $iniPath
if ($file.IsReadOnly) { $file.IsReadOnly = $false }
Unblock-File -LiteralPath $iniPath -ErrorAction SilentlyContinue
}

if (Test-Path $taskPath) {
$file = Get-Item -LiteralPath $taskPath
if ($file.IsReadOnly) { $file.IsReadOnly = $false }
Unblock-File -LiteralPath $taskPath -ErrorAction SilentlyContinue
}

# Copy the ini to program files
Copy-Item -Path $iniPath -Destination "C:\Program Files (x86)\InterSoft International, Inc\NetTerm\"

# Copy the scheduled task powershell to program files
Copy-Item -Path $taskPath -Destination "C:\Program Files (x86)\InterSoft International, Inc\NetTerm\"

# Copy the ini to the appdata folder for current user
Copy-Item -Path "C:\Program Files (x86)\InterSoft International, Inc\NetTerm\basys_netterm.ini" -Destination "$env:APPDATA\InterSoft Common\netterm.ini"

# Make a scheduled task to copy the ini to the current user at logon
$Action = New-ScheduledTaskAction -Execute "powershell.exe" -ArgumentList "-File 'C:\Program Files (x86)\InterSoft International, Inc\NetTerm\ini.ps1'"
$Trigger = New-ScheduledTaskTrigger -AtLogOn
Register-ScheduledTask -TaskName "BasysIni" -Action $Action -Trigger $Trigger -Description "Copy Basys.ini to appdata"

# Check Dependencies
Write-Log "3. Dependency Install" "START"

$dependencies = @(
@{
Name = "Microsoft.NET.CoreRuntime.2.2"
File = "Microsoft.NET.CoreRuntime.2.2.appx"
Url = "https://github.com/PCSSupport/BASysGlobal/raw/refs/heads/main/Dependencies/x64/Microsoft.NET.CoreRuntime.2.2.appx"
},
@{
Name = "Microsoft.NET.CoreFramework.Debug.2.2"
File = "Microsoft.NET.CoreFramework.Debug.2.2.appx"
Url = "https://github.com/PCSSupport/BASysGlobal/raw/refs/heads/main/Dependencies/x64/Microsoft.NET.CoreFramework.Debug.2.2.appx"
},
@{
Name = "Microsoft.VCLibs.140.00_14.0.27825.0_x64__8wekyb3d8bbwe"
File = "Microsoft.VCLibs.x64.14.00.appx"
Url = "https://github.com/PCSSupport/BASysGlobal/raw/refs/heads/main/Dependencies/x64/Microsoft.VCLibs.x64.14.00.appx"
}
)

$tempDir = "C:\TEMP\Dependencies"
$null = New-Item -ItemType Directory -Path $tempDir -Force

foreach ($dep in $dependencies) {
$pkgName = $dep.Name
$pkgFile = $dep.File
$pkgPath = "$tempDir\$pkgFile"
$pkgUrl = $dep.Url

try {
# Skip if already installed
if (Get-AppxPackage -Name $pkgName -ErrorAction SilentlyContinue) {
Write-Log "3. Dependency Install" "INFO" "$pkgName already installed"
continue
}

# Download
Write-Log "3. Dependency Install" "INFO" "Downloading $pkgFile ..."
Invoke-WebRequest -Uri $pkgUrl -OutFile $pkgPath -ErrorAction Stop

# Install
Write-Log "3. Dependency Install" "INFO" "Installing $pkgFile ..."
Add-AppxPackage -Path $pkgPath -ErrorAction Stop

Write-Log "3. Dependency Install" "SUCCESS" "$pkgName installed"
} catch {
Write-Log "3. Dependency Install" "FAILED" "$pkgName : $($_.Exception.Message)"
}
}

# Install Retread.Mfg.Client.Windows MSIXBundle
Write-Log "4. Retread Client Install" "START"

$bundleUrl = "https://github.com/PCSSupport/BASysGlobal/raw/refs/heads/main/Retread.Mfg.Client.Windows_1.57.0.128_x64.msixbundle"
$bundleName = "Retread.Mfg.Client.Windows_1.57.0.128_x64.msixbundle"
$bundlePath = "$tempDir\$bundleName"

try {
Write-Log "4. Retread Client Install" "INFO" "Downloading $bundleName ..."
Invoke-WebRequest -Uri $bundleUrl -OutFile $bundlePath -ErrorAction Stop

Write-Log "4. Retread Client Install" "INFO" "Installing $bundleName ..."
Add-AppxPackage -Path $bundlePath -ErrorAction Stop

Write-Log "4. Retread Client Install" "SUCCESS" "Retread.Mfg.Client.Windows installed"
} catch {
Write-Log "4. Retread Client Install" "FAILED" $_.Exception.Message
}
# Clean up - delete startup shortcut
Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run' -Name 'execute_provisioning' -ErrorAction SilentlyContinue

Write-Log "=== FINAL ERROR DUMP ===" "INFO"
$Error | ForEach-Object { Write-Log "GLOBAL ERROR" "ERROR" $_.Exception.Message }

# Final log
Write-Log "=== PROVISIONING COMPLETE ===" "COMPLETE"



