if(test-path "$env:APPDATA\InterSoft Common\check.ini")
{
    #Do nothing the check.ini file is aready in appdata
}
else
{
	Copy-Item -Path "C:\Program Files (x86)\InterSoft International, Inc\NetTerm\basys_netterm.ini" -Destination "$env:APPDATA\InterSoft Common\netterm.ini"
	Copy-Item -Path "C:\Program Files (x86)\InterSoft International, Inc\NetTerm\check.ini" -Destination "$env:APPDATA\InterSoft Common\check.ini"

}